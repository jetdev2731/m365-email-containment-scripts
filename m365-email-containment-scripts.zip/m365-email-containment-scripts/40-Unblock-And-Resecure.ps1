# 40-Unblock-And-Resecure.ps1
<#
This helper prints a post-remediation checklist.
No tenant changes are made by default.
#>

. "$PSScriptRoot\00-Inputs.ps1"

@"
Post-Remediation Checklist
--------------------------
1) Verify affected users can sign in and MFA prompts occur.
2) Re-enable only legitimate inbox rules (if any), audit changes.
3) Confirm no mailbox-level forwarding is set.
4) Rotate app passwords/legacy clients or disable basic auth entirely.
5) Confirm anti-phishing/impersonation policies cover execs & finance.
6) Keep DMARC policy at p=quarantine or p=reject after monitoring.
7) Review SecOps alerts for unusual OAuth app consents.
"@ | Write-Output
