# 20-Graph-RevokeAndReset.ps1
<#
Purpose: Revoke user sessions and set a strong temporary password
         (Force change at next sign-in).
Requires: Microsoft Graph PowerShell; Directory.AccessAsUser.All or sufficient delegated rights
         to update user objects.
#>

. "$PSScriptRoot\00-Inputs.ps1"
Write-Log "Starting Graph revoke & reset"

try {
    if (-not (Get-Module -ListAvailable -Name Microsoft.Graph)) {
        Install-Module Microsoft.Graph -Scope CurrentUser -Force
    }
    Import-Module Microsoft.Graph.Users -ErrorAction Stop
    Connect-MgGraph -Scopes "User.ReadWrite.All","Directory.ReadWrite.All" -ErrorAction Stop
    Write-Log "Connected to Microsoft Graph"
} catch {
    Write-Log "Failed to connect to Graph: $_" 'ERROR'
    throw
}

function New-TempPassword {
    # 20 char complex
    $chars = @(
        [char[]]'ABCDEFGHJKLMNPQRSTUVWXYZ',
        [char[]]'abcdefghijkmnopqrstuvwxyz',
        [char[]]'23456789',
        [char[]]'!@#$%^&*()-_=+[]{}:;,.?'
    )
    $rnd = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
    $bytes = New-Object byte[] 20
    $sb = New-Object System.Text.StringBuilder
    foreach ($set in $chars) {
        $bytes[0] = 0; $rnd.GetBytes($bytes)
        $sb.Append($set[$bytes[0] % $set.Length]) | Out-Null
    }
    for ($i=0;$i -lt 16;$i++) {
        $set = $chars[(Get-Random -Minimum 0 -Maximum $chars.Length)]
        $bytes[0] = 0; $rnd.GetBytes($bytes)
        $sb.Append($set[$bytes[0] % $set.Length]) | Out-Null
    }
    $sb.ToString()
}

$users = Import-Users
$report = @()

foreach ($u in $users) {
    $upn = $u.UserPrincipalName.Trim()
    $entry = [ordered]@{
        UserPrincipalName = $upn
        RevokeOk = $false
        TempPasswordSet = $false
        Notes = ""
    }

    try {
        $user = Get-MgUser -UserId $upn -ErrorAction Stop
    } catch {
        $entry.Notes = "User not found"
        $report += [pscustomobject]$entry
        continue
    }

    # Revoke sessions
    try {
        Revoke-MgUserSignInSession -UserId $user.Id -ErrorAction Stop | Out-Null
        $entry.RevokeOk = $true
    } catch {
        $entry.Notes += "Revoke failed; "
        Write-Log "Revoke failed for $upn: $_" 'WARN'
    }

    # Set temp password
    try {
        $pwd = New-TempPassword
        Update-MgUser -UserId $user.Id -PasswordProfile @{ password=$pwd; forceChangePasswordNextSignIn=$true } -ErrorAction Stop
        # Store redacted hint only
        $hint = $pwd.Substring(0,4) + "****" + $pwd.Substring($pwd.Length-2,2)
        $entry.TempPasswordSet = $true
        $entry.Notes += "Temp password hint: $hint"
    } catch {
        $entry.Notes += "Pwd set failed"
        Write-Log "Password set failed for $upn: $_" 'WARN'
    }

    $report += [pscustomobject]$entry
}

$csv = Join-Path $ReportPath ("graph_reset_{0}.csv" -f (Get-Date -Format "yyyyMMddHHmmss"))
$report | Export-Csv -NoTypeInformation -Path $csv -Encoding UTF8
Write-Log "Graph revoke & reset complete. Report: $csv"
