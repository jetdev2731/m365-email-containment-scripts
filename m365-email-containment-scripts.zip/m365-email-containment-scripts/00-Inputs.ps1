# 00-Inputs.ps1
<#
Shared settings for the M365 email containment scripts.
Place this file in the same folder as the other .ps1 files.
#>

# Resolve paths
$ScriptRoot   = Split-Path -Parent $MyInvocation.MyCommand.Path
$OutRoot      = Join-Path $ScriptRoot 'output'
$LogPath      = Join-Path $OutRoot   'logs'
$BackupPath   = Join-Path $OutRoot   'backups'
$ReportPath   = Join-Path $OutRoot   'reports'
$UsersCsvPath = Join-Path $ScriptRoot 'users.csv'

# Ensure folders
$null = New-Item -Path $OutRoot   -ItemType Directory -Force
$null = New-Item -Path $LogPath   -ItemType Directory -Force
$null = New-Item -Path $BackupPath -ItemType Directory -Force
$null = New-Item -Path $ReportPath-ItemType Directory -Force

# Simple logger
function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO','WARN','ERROR')][string]$Level='INFO'
    )
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = "[$ts][$Level] $Message"
    Write-Host $line
    $line | Out-File -FilePath (Join-Path $LogPath 'run.log') -Append -Encoding utf8
}

# Import users
function Import-Users {
    if (!(Test-Path $UsersCsvPath)) {
        throw "users.csv not found at $UsersCsvPath"
    }
    try {
        $users = Import-Csv -Path $UsersCsvPath
        if (-not $users -or -not $users[0].UserPrincipalName) {
            throw "users.csv missing 'UserPrincipalName' column."
        }
        return $users
    } catch {
        throw "Failed to import users.csv. $_"
    }
}

Write-Log "Loaded 00-Inputs.ps1"
