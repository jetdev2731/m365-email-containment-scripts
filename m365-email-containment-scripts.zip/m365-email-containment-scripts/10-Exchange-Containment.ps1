# 10-Exchange-Containment.ps1
<#
Purpose: Contain mailbox misuse by backing up and disabling risky inbox rules
and clearing mailbox-level forwarding.
Requires: Exchange Online PowerShell (EXO V3+) and appropriate RBAC.
#>

. "$PSScriptRoot\00-Inputs.ps1"
Write-Log "Starting Exchange containment"

# Connect (interactive by default)
try {
    if (-not (Get-Module -ListAvailable -Name ExchangeOnlineManagement)) {
        Install-Module ExchangeOnlineManagement -Scope CurrentUser -Force -AllowClobber
    }
    Import-Module ExchangeOnlineManagement -ErrorAction Stop
    Connect-ExchangeOnline -ShowBanner:$false
    Write-Log "Connected to Exchange Online"
} catch {
    Write-Log "Failed to connect to Exchange Online: $_" 'ERROR'
    throw
}

$users = Import-Users
$summary = @()

foreach ($u in $users) {
    $upn = $u.UserPrincipalName.Trim()
    Write-Log "Processing $upn"

    $entry = [ordered]@{
        UserPrincipalName = $upn
        MailboxFound      = $false
        ClearedForwarding = $false
        DisabledRules     = 0
        Notes             = ""
    }

    try {
        $mbx = Get-Mailbox -Identity $upn -ErrorAction Stop
        $entry.MailboxFound = $true
    } catch {
        $entry.Notes = "Mailbox not found"
        $summary += [pscustomobject]$entry
        continue
    }

    # Backup existing inbox rules
    try {
        $rules = Get-InboxRule -Mailbox $upn -ErrorAction SilentlyContinue
        $backupFile = Join-Path $BackupPath ("{0}-rules-{1}.json" -f $upn, (Get-Date -Format "yyyyMMddHHmmss"))
        $rules | ConvertTo-Json -Depth 5 | Out-File -FilePath $backupFile -Encoding utf8
        Write-Log "Backed up rules to $backupFile"
    } catch {
        Write-Log "Failed to backup rules for $upn: $_" 'WARN'
    }

    # Disable suspected forwarding/redirect rules
    $disabled = 0
    foreach ($r in ($rules | Where-Object { $_.ForwardTo -or $_.RedirectTo -or $_.ForwardAsAttachmentTo })) {
        try {
            Set-InboxRule -Identity $r.Identity -Mailbox $upn -Enabled:$false -ErrorAction Stop
            $disabled++
        } catch {
            Write-Log "Failed to disable rule '$($r.Name)' for $upn: $_" 'WARN'
        }
    }
    $entry.DisabledRules = $disabled

    # Clear mailbox-level forwarding
    try {
        Set-Mailbox -Identity $upn -ForwardingSmtpAddress $null -ForwardingAddress $null -DeliverToMailboxAndForward:$false -ErrorAction Stop
        $entry.ClearedForwarding = $true
    } catch {
        Write-Log "Failed to clear mailbox forwarding for $upn: $_" 'WARN'
    }

    $summary += [pscustomobject]$entry
}

# Save summary
$csv = Join-Path $ReportPath ("containment_summary_{0}.csv" -f (Get-Date -Format "yyyyMMddHHmmss"))
$summary | Export-Csv -NoTypeInformation -Path $csv -Encoding UTF8
Write-Log "Containment complete. Summary: $csv"

Disconnect-ExchangeOnline -Confirm:$false
