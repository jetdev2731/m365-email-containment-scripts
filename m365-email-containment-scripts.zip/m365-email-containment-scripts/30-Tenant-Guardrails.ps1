# 30-Tenant-Guardrails.ps1
<#
Purpose: Tenant-level anti-abuse guardrails.
 - Block external auto-forwarding on the default hosted outbound spam policy.
 - Ensure UnifiedAuditLogIngestion is enabled for Exchange admin audit.
Requires: EXO V3+
#>

. "$PSScriptRoot\00-Inputs.ps1"
Write-Log "Applying tenant guardrails"

try {
    if (-not (Get-Module -ListAvailable -Name ExchangeOnlineManagement)) {
        Install-Module ExchangeOnlineManagement -Scope CurrentUser -Force -AllowClobber
    }
    Import-Module ExchangeOnlineManagement -ErrorAction Stop
    Connect-ExchangeOnline -ShowBanner:$false
    Write-Log "Connected to Exchange Online"
} catch {
    Write-Log "Failed to connect to Exchange Online: $_" 'ERROR'
    throw
}

# Hosted outbound spam policy
try {
    $default = Get-HostedOutboundSpamFilterPolicy | Where-Object { $_.IsDefault -eq $true } | Select-Object -First 1
    if ($null -eq $default) { $default = Get-HostedOutboundSpamFilterPolicy | Select-Object -First 1 }
    if ($default) {
        Write-Log "Current AutoForwardingMode on '$($default.Name)': $($default.AutoForwardingMode)"
        if ($default.AutoForwardingMode -ne 'Off') {
            Set-HostedOutboundSpamFilterPolicy -Identity $default.Identity -AutoForwardingMode Off
            Write-Log "Set AutoForwardingMode to Off on '$($default.Name)'"
        } else {
            Write-Log "AutoForwardingMode already Off"
        }
    } else {
        Write-Log "No HostedOutboundSpamFilterPolicy found" 'WARN'
    }
} catch {
    Write-Log "Failed to enforce auto-forwarding policy: $_" 'WARN'
}

# Ensure Exchange admin audit ingestion enabled
try {
    Set-AdminAuditLogConfig -UnifiedAuditLogIngestionEnabled $true -ErrorAction SilentlyContinue
    $cfg = Get-AdminAuditLogConfig
    Write-Log "UnifiedAuditLogIngestionEnabled: $($cfg.UnifiedAuditLogIngestionEnabled)"
} catch {
    Write-Log "Failed to set audit log ingestion: $_" 'WARN'
}

Disconnect-ExchangeOnline -Confirm:$false
Write-Log "Guardrails applied"
