# 90-Status-Report.ps1
<#
Purpose: Validate that forwarding is cleared and risky rules are disabled.
#>

. "$PSScriptRoot\00-Inputs.ps1"
Write-Log "Running status report"

try {
    if (-not (Get-Module -ListAvailable -Name ExchangeOnlineManagement)) {
        Install-Module ExchangeOnlineManagement -Scope CurrentUser -Force -AllowClobber
    }
    Import-Module ExchangeOnlineManagement -ErrorAction Stop
    Connect-ExchangeOnline -ShowBanner:$false
    Write-Log "Connected to Exchange Online"
} catch {
    Write-Log "Failed to connect to Exchange Online: $_" 'ERROR'
    throw
}

$users = Import-Users
$rows = @()

foreach ($u in $users) {
    $upn = $u.UserPrincipalName.Trim()
    $row = [ordered]@{
        UserPrincipalName = $upn
        MailboxFound = $false
        MailboxForwarding = $false
        ForwardingRuleCount = 0
    }
    try {
        $mbx = Get-Mailbox -Identity $upn -ErrorAction Stop
        $row.MailboxFound = $true

        if ($mbx.ForwardingSmtpAddress -or $mbx.ForwardingAddress -or $mbx.DeliverToMailboxAndForward) {
            $row.MailboxForwarding = $true
        }

        $rules = Get-InboxRule -Mailbox $upn -ErrorAction SilentlyContinue | Where-Object { $_.Enabled -and ($_.ForwardTo -or $_.RedirectTo -or $_.ForwardAsAttachmentTo) }
        $row.ForwardingRuleCount = @($rules).Count
    } catch {}

    $rows += [pscustomobject]$row
}

$csv = Join-Path $ReportPath ("status_report_{0}.csv" -f (Get-Date -Format "yyyyMMddHHmmss"))
$rows | Export-Csv -NoTypeInformation -Path $csv -Encoding UTF8
Write-Log "Status report exported to $csv"

Disconnect-ExchangeOnline -Confirm:$false
